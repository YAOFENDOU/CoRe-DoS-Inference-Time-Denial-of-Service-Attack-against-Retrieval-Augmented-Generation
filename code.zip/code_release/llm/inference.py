"""
LLM
"""
import torch
from typing import Optional, List
import os

def generate_answer(
    model,
    tokenizer,
    prompt: str,
    max_new_tokens: int = 256,
    temperature: float = 0.7,
    top_p: float = 0.9,
    do_sample: bool = True,
    repetition_penalty: float = 1.0
) -> str:
    """
    
    
    Args:
        model: 
        tokenizer: 
        prompt: 
        max_new_tokens: token
        temperature: 
        top_p: Top-p
        do_sample: 
        repetition_penalty: 
    
    Returns:
        
    """

    model_name = getattr(model.config, '_name_or_path', '').lower()
    is_qwen = 'qwen' in model_name
    
    device_moved = False
    if is_qwen:

        try:
            if hasattr(tokenizer, 'apply_chat_template'):
                messages = [{"role": "user", "content": prompt}]
                text = tokenizer.apply_chat_template(
                    messages,
                    tokenize=False,
                    add_generation_prompt=True
                )
                inputs = tokenizer([text], return_tensors="pt")
            elif hasattr(tokenizer, 'build_chat_input'):

                inputs = tokenizer.build_chat_input(prompt, history=[], role="user")
                inputs = {k: v.to(model.device) for k, v in inputs.items()}
                device_moved = True
            else:

                inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=2048)
        except Exception as e:
            print(f"Qwen chat template，: {e}")
            inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=2048)
    else:

        inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=2048)
    
    if not device_moved:
        inputs = inputs.to(model.device)
    

    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            top_p=top_p,
            do_sample=do_sample,
            repetition_penalty=repetition_penalty,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id
        )
    

    if hasattr(inputs, 'input_ids'):
        input_length = inputs.input_ids.shape[1]
    elif 'input_ids' in inputs:
        input_length = inputs['input_ids'].shape[1]
    else:
        input_length = 0
    
    generated_tokens = outputs[0][input_length:]
    answer = tokenizer.decode(generated_tokens, skip_special_tokens=True)
    
    return answer.strip()

def generate_answer_api(
    api_name: str,
    prompt: str,
    model_name: Optional[str] = None,
    max_tokens: int = 256,
    temperature: float = 0.7,
    api_key: Optional[str] = None
) -> str:
    """
    API
    
    Args:
        api_name: API ("openai", "anthropic", "vectorengine")
        prompt: 
        model_name: 
        max_tokens: token
        temperature: 
        api_key: API
    
    Returns:
        
    """
    if api_name == "openai":
        return _generate_openai(prompt, model_name or "gpt-4", max_tokens, temperature, api_key)
    elif api_name == "anthropic":
        return _generate_anthropic(prompt, model_name or "claude-3-sonnet-20240229", max_tokens, temperature, api_key)
    elif api_name == "vectorengine":
        return _generate_vectorengine(prompt, model_name or "gpt-4", max_tokens, temperature, api_key)
    else:
        raise ValueError(f"API: {api_name}")

def _generate_openai(prompt: str, model: str, max_tokens: int, temperature: float, api_key: Optional[str]) -> str:
    """OpenAI API"""
    try:
        import openai
        
        if api_key:
            openai.api_key = api_key
        else:
            openai.api_key = os.getenv("OPENAI_API_KEY")
        
        response = openai.ChatCompletion.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=max_tokens,
            temperature=temperature
        )
        
        return response.choices[0].message.content.strip()
    
    except Exception as e:
        print(f"OpenAI API: {e}")
        return ""

def _generate_anthropic(prompt: str, model: str, max_tokens: int, temperature: float, api_key: Optional[str]) -> str:
    """Anthropic API"""
    try:
        import anthropic
        
        if api_key:
            client = anthropic.Anthropic(api_key=api_key)
        else:
            client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
        
        message = client.messages.create(
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            messages=[{"role": "user", "content": prompt}]
        )
        
        return message.content[0].text.strip()
    
    except Exception as e:
        print(f"Anthropic API: {e}")
        return ""

def _generate_vectorengine(prompt: str, model: str, max_tokens: int, temperature: float, api_key: Optional[str]) -> str:
    """VectorEngine API（OpenAI）"""
    import time
    import requests
    

    if api_key:
        key = api_key
    else:
        key = os.getenv("VECTORENGINE_API_KEY")
    
    if not key:
        raise ValueError(" VECTORENGINE_API_KEY  api_key")
    

    api_url = "https://api.vectorengine.ai/v1/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {key}",
    }
    
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    

    max_retries = 3
    retry_delay = 2  
    
    for attempt in range(max_retries):
        try:

            response = requests.post(api_url, headers=headers, json=payload, timeout=120)
            response.raise_for_status()
            data = response.json()
            

            return data["choices"][0]["message"]["content"].strip()
        
        except requests.exceptions.HTTPError as e:
            if response.status_code == 503 and attempt < max_retries - 1:

                print(f"⚠️ API (503)，{retry_delay}... ( {attempt+1}/{max_retries})")
                time.sleep(retry_delay)
                retry_delay *= 2  
                continue
            elif response.status_code == 429 and attempt < max_retries - 1:

                print(f"⚠️  (429)，{retry_delay}... ( {attempt+1}/{max_retries})")
                time.sleep(retry_delay)
                retry_delay *= 2
                continue
            else:

                print(f"❌ VectorEngine API ({response.status_code}): {response.text}")
                return ""
        
        except requests.exceptions.Timeout:
            if attempt < max_retries - 1:
                print(f"⚠️ ，{retry_delay}... ( {attempt+1}/{max_retries})")
                time.sleep(retry_delay)
                retry_delay *= 2
                continue
            else:
                print(f"❌ VectorEngine API")
                return ""
        
        except Exception as e:
            print(f"❌ VectorEngine API: {e}")
            import traceback
            traceback.print_exc()
            return ""
    
    return ""

def batch_generate(
    model,
    tokenizer,
    prompts: List[str],
    batch_size: int = 4,
    **generation_kwargs
) -> List[str]:
    """
    
    
    Args:
        model: 
        tokenizer: 
        prompts: 
        batch_size: 
        **generation_kwargs: 
    
    Returns:
        
    """
    answers = []
    
    for i in range(0, len(prompts), batch_size):
        batch_prompts = prompts[i:i+batch_size]
        

        inputs = tokenizer(
            batch_prompts,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=2048
        )
        inputs = inputs.to(model.device)
        

        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=generation_kwargs.get("max_new_tokens", 256),
                temperature=generation_kwargs.get("temperature", 0.7),
                top_p=generation_kwargs.get("top_p", 0.9),
                do_sample=generation_kwargs.get("do_sample", True),
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id
            )
        

        for j, output in enumerate(outputs):
            input_length = inputs.input_ids[j].shape[0]
            generated_tokens = output[input_length:]
            answer = tokenizer.decode(generated_tokens, skip_special_tokens=True)
            answers.append(answer.strip())
    
    return answers

class LLMInference:
    """LLM"""
    
    def __init__(self, model, tokenizer=None, is_api=False, api_name=None):
        """
        
        
        Args:
            model: API
            tokenizer: （）
            is_api: API
            api_name: API
        """
        self.model = model
        self.tokenizer = tokenizer
        self.is_api = is_api
        self.api_name = api_name
    
    def generate(self, prompt: str, **kwargs) -> str:
        """
        
        
        Args:
            prompt: 
            **kwargs: 
        
        Returns:
            
        """
        if self.is_api:
            return generate_answer_api(
                self.api_name,
                prompt,
                **kwargs
            )
        else:
            return generate_answer(
                self.model,
                self.tokenizer,
                prompt,
                **kwargs
            )
    
    def batch_generate(self, prompts: List[str], **kwargs) -> List[str]:
        """
        
        
        Args:
            prompts: 
            **kwargs: 
        
        Returns:
            
        """
        if self.is_api:

            return [self.generate(p, **kwargs) for p in prompts]
        else:
            return batch_generate(
                self.model,
                self.tokenizer,
                prompts,
                **kwargs
            )

if __name__ == "__main__":

    from model_loader import load_llm_by_alias
    
    print("...")
    model, tokenizer = load_llm_by_alias("llama2-7b", load_in_8bit=True)
    
    prompt = "What is the capital of France?"
    print(f"\n: {prompt}")
    
    answer = generate_answer(model, tokenizer, prompt, max_new_tokens=50)
    print(f": {answer}")
