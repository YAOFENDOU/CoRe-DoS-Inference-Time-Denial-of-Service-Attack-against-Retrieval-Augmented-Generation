"""
LLM
"""
import os
from typing import Tuple, Optional

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM


DATA_ROOT = os.getenv("DATA_ROOT", "/root/autodl-tmp")
HF_CACHE_DIR = os.path.join(DATA_ROOT, ".cache", "huggingface")
MODELSCOPE_CACHE_DIR = os.path.join(DATA_ROOT, ".cache", "modelscope")


def _ensure_hf_cache_on_data_disk():
    """HuggingFace，。"""
    os.makedirs(HF_CACHE_DIR, exist_ok=True)
    if not os.getenv("HF_HOME"):
        os.environ["HF_HOME"] = HF_CACHE_DIR
    if not os.getenv("TRANSFORMERS_CACHE"):
        os.environ["TRANSFORMERS_CACHE"] = HF_CACHE_DIR


def _ensure_modelscope_cache_on_data_disk():
    """ModelScope。"""
    os.makedirs(MODELSCOPE_CACHE_DIR, exist_ok=True)
    if not os.getenv("MODELSCOPE_CACHE"):
        os.environ["MODELSCOPE_CACHE"] = MODELSCOPE_CACHE_DIR


def download_model_from_modelscope(model_id: str, revision: Optional[str] = None) -> str:
    """ModelScope。"""
    _ensure_modelscope_cache_on_data_disk()
    try:
        from modelscope import snapshot_download
    except ImportError as exc:
        raise RuntimeError(
            "modelscope， `pip install modelscope` "
        ) from exc

    kwargs = {
        "model_id": model_id,
        "cache_dir": MODELSCOPE_CACHE_DIR,
    }
    if revision:
        kwargs["revision"] = revision

    local_path = snapshot_download(**kwargs)
    return local_path

def load_llm(model_name: str, 
             device: str = "auto",
             load_in_8bit: bool = False,
             load_in_4bit: bool = False,
             torch_dtype: str = "auto",
             trust_remote_code: bool = False) -> Tuple:
    """
    LLM
    
    Args:
        model_name: 
        device:  ("auto", "cuda", "cpu")
        load_in_8bit: 8bit
        load_in_4bit: 4bit
        torch_dtype: torch
        trust_remote_code: 
    
    Returns:
        (model, tokenizer) 
    """
    _ensure_hf_cache_on_data_disk()

    print(f": {model_name}")
    

    if torch_dtype == "auto":
        dtype = torch.float16 if torch.cuda.is_available() else torch.float32
    elif torch_dtype == "float16":
        dtype = torch.float16
    elif torch_dtype == "bfloat16":
        dtype = torch.bfloat16
    else:
        dtype = torch.float32
    

    try:
        tokenizer = AutoTokenizer.from_pretrained(
            model_name,
            trust_remote_code=trust_remote_code,
            use_fast=False
        )
        

        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        
        print("Tokenizer")
    except Exception as e:
        print(f"tokenizer: {e}")
        raise
    

    try:
        load_kwargs = {
            "torch_dtype": dtype,
            "trust_remote_code": trust_remote_code,
        }
        

        if load_in_8bit:
            load_kwargs["load_in_8bit"] = True
            load_kwargs["device_map"] = "auto"
        elif load_in_4bit:
            load_kwargs["load_in_4bit"] = True
            load_kwargs["device_map"] = "auto"
        elif device == "auto":
            load_kwargs["device_map"] = "auto"
        
        model = AutoModelForCausalLM.from_pretrained(
            model_name,
            **load_kwargs
        )
        

        if device not in ["auto"] and not (load_in_8bit or load_in_4bit):
            model = model.to(device)
        
        model.eval()
        
        print(f"，: {next(model.parameters()).device}")
        
    except Exception as e:
        print(f": {e}")
        raise
    
    return model, tokenizer

def load_llm_for_api(api_name: str, api_key: Optional[str] = None) -> str:
    """
    API
    
    Args:
        api_name: API ("openai", "anthropic", etc.)
        api_key: API
    
    Returns:
        
    """
    if api_key is None:

        if api_name == "openai":
            api_key = os.getenv("OPENAI_API_KEY")
        elif api_name == "anthropic":
            api_key = os.getenv("ANTHROPIC_API_KEY")
    
    if api_key is None:
        print(f": {api_name}API")
    
    print(f"API: {api_name}")
    return f"{api_name}-api"


MODEL_CONFIGS = {
    "llama2-7b": {

        "model_name": "daryl149/llama-2-7b-chat-hf",
        "torch_dtype": "float16",
    },
    "llama3-8b": {
        "model_name": "meta-llama/Meta-Llama-3-8B-Instruct",
        "torch_dtype": "float16",
    },
    "mistral-7b": {
        "model_name": "mistralai/Mistral-7B-Instruct-v0.2",
        "torch_dtype": "float16",
    },
    "vicuna-7b": {
        "model_name": "lmsys/vicuna-7b-v1.3",
        "torch_dtype": "float16",
    },
    "qwen-7b": {
        "model_name": "Qwen/Qwen-7B-Chat",
        "torch_dtype": "float16",
        "trust_remote_code": True,
    },
    "qwen2-7b": {
        "model_name": "Qwen/Qwen2-7B-Instruct",
        "torch_dtype": "float16",
        "trust_remote_code": True,
    },
    "phi-3-mini": {
        "model_name": "microsoft/Phi-3-mini-4k-instruct",
        "torch_dtype": "float16",
        "trust_remote_code": True,
    },
    "gemma-7b": {
        "model_name": "google/gemma-7b-it",
        "torch_dtype": "float16",
    },
}

def load_llm_by_alias(alias: str, **kwargs) -> Tuple:
    """
    
    
    Args:
        alias: 
        **kwargs: 
    
    Returns:
        (model, tokenizer) 
    """
    if alias not in MODEL_CONFIGS:
        raise ValueError(f": {alias}")
    
    config = MODEL_CONFIGS[alias].copy()
    config.update(kwargs)
    
    return load_llm(**config)

if __name__ == "__main__":

    import argparse
    
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, default="llama2-7b")
    parser.add_argument("--load_in_8bit", action="store_true")
    
    args = parser.parse_args()
    
    try:
        model, tokenizer = load_llm_by_alias(args.model, load_in_8bit=args.load_in_8bit)
        print("！")
    except Exception as e:
        print(f": {e}")
