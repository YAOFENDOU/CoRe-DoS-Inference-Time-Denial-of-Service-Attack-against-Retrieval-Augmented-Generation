"""
 - 
(blocker)
"""
from typing import List, Dict, Optional
import tiktoken


MODEL_MAX_CONTEXT = {
    'llama2': 2048,      # Llama2-7B
    'llama-2': 2048,
    'llama3': 8192,      # Llama3-8B
    'llama-3': 8192,
    'mistral': 8192,     # Mistral-7B
    'qwen': 32768,       # Qwen-7B
    'vicuna': 2048,      
    'default': 2048      
}

class ContextLengthManager:
    """
    
    ，
    """
    
    def __init__(self, model_name: str, tokenizer=None):
        """
        
        
        Args:
            model_name: 
            tokenizer: tokenizer（，token）
        """
        self.model_name = model_name.lower()
        self.tokenizer = tokenizer
        self.max_context_length = self._get_max_context_length()
        

        self.reserved_for_query = 100        
        self.reserved_for_blocker = 300      
        self.reserved_for_response = 100     
        self.safety_margin = 200             
        

        self.max_docs_tokens = (
            self.max_context_length 
            - self.reserved_for_query 
            - self.reserved_for_blocker 
            - self.reserved_for_response
            - self.safety_margin
        )
        
        print(f"[] ")
        print(f"  : {model_name}")
        print(f"  : {self.max_context_length} tokens")
        print(f"  : {self.max_docs_tokens} tokens")
    
    def _get_max_context_length(self) -> int:
        """"""
        for key, length in MODEL_MAX_CONTEXT.items():
            if key in self.model_name:
                return length
        return MODEL_MAX_CONTEXT['default']
    
    def estimate_tokens(self, text: str) -> int:
        """
        token
        
        Args:
            text: 
            
        Returns:
            token
        """
        if self.tokenizer is not None:

            try:
                return len(self.tokenizer.encode(text))
            except:
                pass
        


        return len(text) // 3
    
    def truncate_documents(
        self, 
        documents: List[str], 
        blocker_text: Optional[str] = None,
        blocker_repeat: int = 1,
        insert_position: str = "end"
    ) -> tuple[List[str], bool]:
        """
        ，
        
        :
        1. blocker，blocker
        2. 
        3. （）
        
        Args:
            documents: 
            blocker_text: blocker（）
            
        Returns:
            
        """
        if not documents:
            return documents, False
        

        blocker_tokens = 0
        if blocker_text:
            blocker_tokens = self.estimate_tokens(blocker_text)

            if insert_position == "replace_first_last":

                blocker_multiplier = 0
            elif insert_position == "both":
                blocker_multiplier = blocker_repeat * 2  
            else:
                blocker_multiplier = blocker_repeat  
            

            available_tokens = (
                self.max_context_length 
                - self.reserved_for_query
                - blocker_tokens * blocker_multiplier  
                - self.reserved_for_response
                - self.safety_margin
            )
        else:
            available_tokens = self.max_docs_tokens
        

        if available_tokens <= 0:
            print(f"[] ，blocker")
            return [], True  
        

        doc_tokens = [self.estimate_tokens(doc) for doc in documents]
        total_tokens = sum(doc_tokens)
        

        if total_tokens <= available_tokens:
            return documents, False  
        

        print(f"[] ，")
        print(f"  tokens: {total_tokens}")
        print(f"  tokens: {available_tokens}")
        

        truncated_docs = []
        target_tokens_per_doc = available_tokens // len(documents)
        
        for doc, doc_token_count in zip(documents, doc_tokens):
            if doc_token_count <= target_tokens_per_doc:

                truncated_docs.append(doc)
            else:


                target_chars = target_tokens_per_doc * 3
                truncated_text = doc[:target_chars]
                truncated_docs.append(truncated_text)
        

        final_total = sum(self.estimate_tokens(doc) for doc in truncated_docs)
        print(f"  tokens: {final_total}")
        
        return truncated_docs, True  
    
    def get_safe_doc_length(self) -> int:
        """
        （）
        
        
        Returns:
            
        """

        tokens_per_doc = self.max_docs_tokens // 5

        chars_per_doc = tokens_per_doc * 3
        return max(chars_per_doc, 200)  

def get_context_manager(model_name: str, tokenizer=None) -> ContextLengthManager:
    """
    ：
    
    Args:
        model_name: 
        tokenizer: tokenizer（）
        
    Returns:
        ContextLengthManager
    """
    return ContextLengthManager(model_name, tokenizer)
