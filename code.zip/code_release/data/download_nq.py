"""
Natural Questions
"""
import os
import json
from datasets import load_dataset
from tqdm import tqdm
import argparse

DEFAULT_DATA_ROOT = "/root/autodl-tmp/rag_attack_data"


def download_nq_dataset(output_dir=f"{DEFAULT_DATA_ROOT}/nq", sample_size=None):
    """
    Natural Questions
    
    Args:
        output_dir: 
        sample_size: ，None
    """
    print("Natural Questions...")
    os.makedirs(output_dir, exist_ok=True)
    
    try:

        dataset = load_dataset("natural_questions", "default", split="train")
        
        if sample_size:
            dataset = dataset.select(range(min(sample_size, len(dataset))))
        
        print(f" {len(dataset)} ")
        

        documents = []
        questions = []
        
        for item in tqdm(dataset, desc=""):

            if "document" in item and "tokens" in item["document"]:
                doc_text = " ".join([token for token in item["document"]["tokens"] if token])
                documents.append({
                    "id": item.get("id", ""),
                    "text": doc_text,
                    "title": item["document"].get("title", "")
                })
            

            if "question" in item:
                questions.append({
                    "id": item.get("id", ""),
                    "question": item["question"]["text"]
                })
        

        doc_file = os.path.join(output_dir, "documents.jsonl")
        with open(doc_file, "w", encoding="utf-8") as f:
            for doc in documents:
                f.write(json.dumps(doc, ensure_ascii=False) + "\n")
        print(f": {doc_file}")
        

        query_file = os.path.join(output_dir, "questions.jsonl")
        with open(query_file, "w", encoding="utf-8") as f:
            for q in questions:
                f.write(json.dumps(q, ensure_ascii=False) + "\n")
        print(f": {query_file}")
        
        print(f"！: {len(documents)}, : {len(questions)}")
        
    except Exception as e:
        print(f": {e}")
        print("datasets: pip install datasets --break-system-packages")

def load_nq_documents(data_dir=f"{DEFAULT_DATA_ROOT}/nq"):
    """NQ"""
    doc_file = os.path.join(data_dir, "documents.jsonl")
    documents = []
    
    with open(doc_file, "r", encoding="utf-8") as f:
        for line in f:
            documents.append(json.loads(line))
    
    return documents

def load_nq_questions(data_dir=f"{DEFAULT_DATA_ROOT}/nq"):
    """NQ"""
    query_file = os.path.join(data_dir, "questions.jsonl")
    questions = []
    
    with open(query_file, "r", encoding="utf-8") as f:
        for line in f:
            questions.append(json.loads(line))
    
    return questions

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Natural Questions")
    parser.add_argument("--output_dir", type=str, default=f"{DEFAULT_DATA_ROOT}/nq",
                       help="")
    parser.add_argument("--sample_size", type=int, default=None,
                       help="")
    
    args = parser.parse_args()
    download_nq_dataset(args.output_dir, args.sample_size)
