"""

"""
import os
import json
import random
import argparse
from typing import List, Dict

def sample_queries(input_file: str, output_file: str, sample_size: int = 100, seed: int = 42):
    """
    
    
    Args:
        input_file: 
        output_file: 
        sample_size: 
        seed: 
    """
    random.seed(seed)
    

    questions = []
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            questions.append(json.loads(line))
    
    print(f": {len(questions)}")
    

    if len(questions) > sample_size:
        sampled = random.sample(questions, sample_size)
    else:
        sampled = questions
    
    print(f": {len(sampled)}")
    

    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    with open(output_file, 'w', encoding='utf-8') as f:
        for q in sampled:
            f.write(json.dumps(q, ensure_ascii=False) + '\n')
    
    print(f"！: {output_file}")

def sample_by_keywords(input_file: str, output_file: str, keywords: List[str], 
                       max_samples: int = 100):
    """
    （）
    
    Args:
        input_file: 
        output_file: 
        keywords: 
        max_samples: 
    """
    matched_questions = []
    
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            q = json.loads(line)
            question_text = q.get('question', '').lower()
            

            if any(kw.lower() in question_text for kw in keywords):
                matched_questions.append(q)
                if len(matched_questions) >= max_samples:
                    break
    
    print(f": {len(matched_questions)}")
    

    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    with open(output_file, 'w', encoding='utf-8') as f:
        for q in matched_questions:
            f.write(json.dumps(q, ensure_ascii=False) + '\n')
    
    print(f"！: {output_file}")

def load_sampled_queries(query_file: str) -> List[Dict]:
    """"""
    queries = []
    with open(query_file, 'r', encoding='utf-8') as f:
        for line in f:
            queries.append(json.loads(line))
    return queries

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="")
    parser.add_argument("--dataset", type=str, choices=["nq", "msmarco"],
                       required=True, help="")
    parser.add_argument("--data_dir", type=str, default="/root/autodl-tmp/rag_attack_data",
                       help="")
    parser.add_argument("--sample_size", type=int, default=100,
                       help="")
    parser.add_argument("--mode", type=str, choices=["random", "keyword"],
                       default="random", help="")
    parser.add_argument("--keywords", type=str, nargs='+',
                       help="（keyword）")
    parser.add_argument("--seed", type=int, default=42,
                       help="")
    
    args = parser.parse_args()
    
    input_file = os.path.join(args.data_dir, args.dataset, "processed", "questions.jsonl")
    output_file = os.path.join(args.data_dir, args.dataset, "sampled_queries.jsonl")
    
    if args.mode == "random":
        sample_queries(input_file, output_file, args.sample_size, args.seed)
    elif args.mode == "keyword":
        if not args.keywords:
            print("：keyword--keywords")
        else:
            sample_by_keywords(input_file, output_file, args.keywords, args.sample_size)
