"""

"""
import os
import json
import re
from bs4 import BeautifulSoup
from tqdm import tqdm
import argparse

DEFAULT_DATA_ROOT = "/root/autodl-tmp/rag_attack_data"

def clean_html(text):
    """HTML"""
    if not text:
        return ""
    soup = BeautifulSoup(text, 'html.parser')
    return soup.get_text()

def clean_text(text):
    """"""
    if not text:
        return ""
    

    text = clean_html(text)
    

    text = re.sub(r'\s+', ' ', text)
    

    text = re.sub(r'[^\w\s\.\,\?\!。，？！]', '', text)
    
    return text.strip()

def preprocess_documents(input_file, output_file, min_length=50):
    """
    
    
    Args:
        input_file: 
        output_file: 
        min_length: 
    """
    print(f": {input_file}")
    
    processed_docs = []
    
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in tqdm(f, desc=""):
            try:
                doc = json.loads(line)
                

                if 'text' in doc:
                    cleaned_text = clean_text(doc['text'])
                    

                    if len(cleaned_text) >= min_length:
                        doc['text'] = cleaned_text
                        processed_docs.append(doc)
            except Exception as e:
                print(f": {e}")
                continue
    

    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    with open(output_file, 'w', encoding='utf-8') as f:
        for doc in processed_docs:
            f.write(json.dumps(doc, ensure_ascii=False) + '\n')
    
    print(f"！: {len(processed_docs)}")
    print(f": {output_file}")

def preprocess_dataset(dataset_name, data_dir=DEFAULT_DATA_ROOT):
    """"""
    input_dir = os.path.join(data_dir, dataset_name)
    output_dir = os.path.join(data_dir, dataset_name, "processed")
    
    os.makedirs(output_dir, exist_ok=True)
    

    doc_input = os.path.join(input_dir, "documents.jsonl")
    doc_output = os.path.join(output_dir, "documents.jsonl")
    
    if os.path.exists(doc_input):
        preprocess_documents(doc_input, doc_output)
    else:
        print(f": {doc_input}")
    

    query_input = os.path.join(input_dir, "questions.jsonl")
    query_output = os.path.join(output_dir, "questions.jsonl")
    
    if os.path.exists(query_input):
        with open(query_input, 'r', encoding='utf-8') as fin:
            with open(query_output, 'w', encoding='utf-8') as fout:
                for line in fin:
                    fout.write(line)
        print(f": {query_output}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="")
    parser.add_argument("--dataset", type=str, choices=["nq", "msmarco", "all"],
                       default="all", help="")
    parser.add_argument("--data_dir", type=str, default=DEFAULT_DATA_ROOT,
                       help="")
    
    args = parser.parse_args()
    
    if args.dataset == "all":
        for ds in ["nq", "msmarco"]:
            preprocess_dataset(ds, args.data_dir)
    else:
        preprocess_dataset(args.dataset, args.data_dir)
