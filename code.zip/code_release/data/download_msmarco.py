"""
MS MARCO
"""
import os
import json
from datasets import load_dataset
from tqdm import tqdm
import argparse

DEFAULT_DATA_ROOT = "/root/autodl-tmp/rag_attack_data"


def download_msmarco_dataset(output_dir=f"{DEFAULT_DATA_ROOT}/msmarco", sample_size=None):
    """
    MS MARCO
    
    Args:
        output_dir: 
        sample_size: ，None
    """
    print("MS MARCO...")
    os.makedirs(output_dir, exist_ok=True)
    
    try:

        dataset = load_dataset("ms_marco", "v1.1", split="train")
        
        if sample_size:
            dataset = dataset.select(range(min(sample_size, len(dataset))))
        
        print(f" {len(dataset)} ")
        

        documents = {}
        questions = []
        
        for item in tqdm(dataset, desc=""):

            if "passages" in item:
                for passage in item["passages"]["passage_text"]:
                    if passage:
                        passage_id = len(documents)
                        documents[passage_id] = {
                            "id": str(passage_id),
                            "text": passage
                        }
            

            if "query" in item:
                questions.append({
                    "id": item.get("query_id", ""),
                    "question": item["query"]
                })
        

        unique_docs = list(documents.values())
        

        doc_file = os.path.join(output_dir, "documents.jsonl")
        with open(doc_file, "w", encoding="utf-8") as f:
            for doc in unique_docs:
                f.write(json.dumps(doc, ensure_ascii=False) + "\n")
        print(f": {doc_file}")
        

        query_file = os.path.join(output_dir, "questions.jsonl")
        with open(query_file, "w", encoding="utf-8") as f:
            for q in questions:
                f.write(json.dumps(q, ensure_ascii=False) + "\n")
        print(f": {query_file}")
        
        print(f"！: {len(unique_docs)}, : {len(questions)}")
        
    except Exception as e:
        print(f": {e}")
        print("datasets: pip install datasets --break-system-packages")

def load_msmarco_documents(data_dir=f"{DEFAULT_DATA_ROOT}/msmarco"):
    """MS MARCO"""
    doc_file = os.path.join(data_dir, "documents.jsonl")
    documents = []
    
    with open(doc_file, "r", encoding="utf-8") as f:
        for line in f:
            documents.append(json.loads(line))
    
    return documents

def load_msmarco_questions(data_dir=f"{DEFAULT_DATA_ROOT}/msmarco"):
    """MS MARCO"""
    query_file = os.path.join(data_dir, "questions.jsonl")
    questions = []
    
    with open(query_file, "r", encoding="utf-8") as f:
        for line in f:
            questions.append(json.loads(line))
    
    return questions

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="MS MARCO")
    parser.add_argument("--output_dir", type=str, default=f"{DEFAULT_DATA_ROOT}/msmarco",
                       help="")
    parser.add_argument("--sample_size", type=int, default=None,
                       help="")
    
    args = parser.parse_args()
    download_msmarco_dataset(args.output_dir, args.sample_size)
