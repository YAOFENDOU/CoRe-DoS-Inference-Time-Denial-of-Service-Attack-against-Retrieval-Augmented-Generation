"""

"""
from typing import List, Dict
import numpy as np

def compute_attack_success_rate(results: List[bool]) -> float:
    """
    
    
    Args:
        results: ，True（）
    
    Returns:
        （0-1）
    """
    if not results:
        return 0.0
    
    success_count = sum(results)
    total_count = len(results)
    
    return success_count / total_count

def compute_trigger_rate(triggered: List[bool]) -> float:
    """
    
    
    Args:
        triggered: ，True
    
    Returns:
        （0-1）
    """
    if not triggered:
        return 0.0
    
    trigger_count = sum(triggered)
    total_count = len(triggered)
    
    return trigger_count / total_count

def compute_precision_recall(predictions: List[bool], ground_truth: List[bool]) -> Dict[str, float]:
    """
    
    
    Args:
        predictions: 
        ground_truth: 
    
    Returns:
        precision, recall, f1
    """
    if len(predictions) != len(ground_truth):
        raise ValueError("")
    
    tp = sum(p and g for p, g in zip(predictions, ground_truth))
    fp = sum(p and not g for p, g in zip(predictions, ground_truth))
    fn = sum(not p and g for p, g in zip(predictions, ground_truth))
    
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
    
    return {
        "precision": precision,
        "recall": recall,
        "f1": f1
    }

def compute_defense_effectiveness(
    attack_success_without_defense: List[bool],
    attack_success_with_defense: List[bool]
) -> Dict[str, float]:
    """
    
    
    Args:
        attack_success_without_defense: 
        attack_success_with_defense: 
    
    Returns:
        
    """
    success_rate_without = compute_attack_success_rate(attack_success_without_defense)
    success_rate_with = compute_attack_success_rate(attack_success_with_defense)
    

    reduction = success_rate_without - success_rate_with
    

    if success_rate_without > 0:
        effectiveness = reduction / success_rate_without
    else:
        effectiveness = 0.0
    
    return {
        "success_rate_without_defense": success_rate_without,
        "success_rate_with_defense": success_rate_with,
        "reduction": reduction,
        "effectiveness": effectiveness
    }

class ExperimentMetrics:
    """"""
    
    def __init__(self):
        """"""
        self.attack_successes = []
        self.trigger_flags = []
        self.response_lengths = []
        self.perplexities = []
    
    def add_result(self, 
                   attack_success: bool,
                   triggered: bool,
                   response: str,
                   perplexity: float = None):
        """
        
        
        Args:
            attack_success: 
            triggered: 
            response: 
            perplexity: （）
        """
        self.attack_successes.append(attack_success)
        self.trigger_flags.append(triggered)
        self.response_lengths.append(len(response))
        
        if perplexity is not None:
            self.perplexities.append(perplexity)
    
    def compute_all_metrics(self) -> Dict[str, float]:
        """
        
        
        Returns:
            
        """
        metrics = {}
        

        metrics["trigger_rate"] = compute_trigger_rate(self.trigger_flags)
        

        triggered_successes = [s for s, t in zip(self.attack_successes, self.trigger_flags) if t]
        if triggered_successes:
            metrics["success_rate_when_triggered"] = compute_attack_success_rate(triggered_successes)
        else:
            metrics["success_rate_when_triggered"] = 0.0
        

        metrics["attack_success_rate"] = metrics["success_rate_when_triggered"]
        

        non_triggered_successes = [s for s, t in zip(self.attack_successes, self.trigger_flags) if not t]
        if non_triggered_successes:

            metrics["refusal_rate_when_not_triggered"] = compute_attack_success_rate(non_triggered_successes)

            metrics["normal_answer_rate_when_not_triggered"] = 1.0 - metrics["refusal_rate_when_not_triggered"]
        else:
            metrics["refusal_rate_when_not_triggered"] = 0.0
            metrics["normal_answer_rate_when_not_triggered"] = 0.0
        

        if self.response_lengths:
            metrics["avg_response_length"] = np.mean(self.response_lengths)
        

        if self.perplexities:
            metrics["avg_perplexity"] = np.mean(self.perplexities)
        

        metrics["total_samples"] = len(self.attack_successes)
        metrics["triggered_samples"] = sum(self.trigger_flags)
        metrics["non_triggered_samples"] = len(self.attack_successes) - sum(self.trigger_flags)
        
        return metrics
    
    def print_summary(self):
        """"""
        metrics = self.compute_all_metrics()
        
        print("\n" + "="*50)
        print("")
        print("="*50)
        print(f": {metrics['total_samples']}")
        print(f": {metrics['triggered_samples']}")
        print(f": {metrics['non_triggered_samples']}")
        print(f": {metrics['trigger_rate']:.2%}")
        print()
        print("【 - 】")
        print(f"   (ASR): {metrics['attack_success_rate']:.2%}")
        print()
        print("【 - 】")
        print(f"  : {metrics['normal_answer_rate_when_not_triggered']:.2%}")
        print(f"   (FPR): {metrics['refusal_rate_when_not_triggered']:.2%}")
        print()
        print("【】")
        print(f"  : {metrics.get('avg_response_length', 0):.1f}")
        if 'avg_perplexity' in metrics:
            print(f"  : {metrics['avg_perplexity']:.2f}")
        print("="*50 + "\n")

if __name__ == "__main__":

    results = [True, True, False, True, False, False, True, True]
    success_rate = compute_attack_success_rate(results)
    print(f": {success_rate:.2%}")
    

    metrics = ExperimentMetrics()
    metrics.add_result(True, True, "Sorry, I cannot answer.", 50.0)
    metrics.add_result(False, True, "Here is the answer...", 30.0)
    metrics.add_result(True, False, "I apologize...", 45.0)
    
    metrics.print_summary()
