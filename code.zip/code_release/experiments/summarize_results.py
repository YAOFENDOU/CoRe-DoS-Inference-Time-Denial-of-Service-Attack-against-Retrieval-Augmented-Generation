#!/usr/bin/env python3
"""

results/，
"""
import json
import os
from pathlib import Path
from typing import Dict, List
import argparse


def load_experiment_result(result_file: Path) -> Dict:
    """"""
    with open(result_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    

    metadata = data.get('metadata', {})
    metrics = data.get('summary', {})
    
    return {
        'file': result_file.name,
        'model': metadata.get('model_name', 'unknown'),
        'temperature': metadata.get('temperature', 0.0),
        'attack_mode': metadata.get('attack_mode', 'unknown'),
        'insert_position': metadata.get('insert_position', 'unknown'),
        'blocker_repeat': metadata.get('blocker_repeat', 1),
        'total_samples': metrics.get('total_samples', 0),
        'trigger_rate': metrics.get('trigger_rate', 0.0),
        'attack_success_rate': metrics.get('attack_success_rate', 0.0),
        'success_when_triggered': metrics.get('success_rate_when_triggered', 0.0),
        'avg_response_length': metrics.get('avg_response_length', 0.0),
    }


def generate_summary_table(results: List[Dict]) -> str:
    """Markdown"""
    

    results_sorted = sorted(results, key=lambda x: x['attack_success_rate'], reverse=True)
    

    lines = [
        "
        "",
        "
        f"- : Few-Shot Contextual Hijacking",
        f"- : both ()",
        f"- : MS MARCO",
        "",
        "
        "",
        "|  |  |  |  |  |  |  |",
        "|------|--------|--------|------------|--------------|--------------|------|"
    ]
    
    for result in results_sorted:
        line = (
            f"| {result['model']:20s} "
            f"| {result['total_samples']:6d} "
            f"| {result['trigger_rate']:6.2%} "
            f"| **{result['attack_success_rate']:6.2%}** "
            f"| {result['success_when_triggered']:6.2%} "
            f"| {result['avg_response_length']:6.1f} "
            f"| {result['temperature']:4.2f} |"
        )
        lines.append(line)
    
    lines.extend([
        "",
        "
        "",
        f"- ****: {results_sorted[0]['model']} ({results_sorted[0]['attack_success_rate']:.2%})",
        f"- ****: {results_sorted[-1]['model']} ({results_sorted[-1]['attack_success_rate']:.2%})",
        f"- ****: {sum(r['attack_success_rate'] for r in results) / len(results):.2%}",
        "",
        "
        "",
        "1. Few-Shot + Query-Aware",
        "2. （both）",
        "3. Few-Shot",
        "",
    ])
    
    return "\n".join(lines)


def generate_latex_table(results: List[Dict]) -> str:
    """LaTeX（）"""
    
    results_sorted = sorted(results, key=lambda x: x['attack_success_rate'], reverse=True)
    
    lines = [
        "\\begin{table}[htbp]",
        "\\centering",
        "\\caption{Attack Success Rates across Different LLMs}",
        "\\label{tab:attack_results}",
        "\\begin{tabular}{lcccc}",
        "\\toprule",
        "Model & Samples & Trigger Rate & Attack Success Rate & Avg. Response Length \\\\",
        "\\midrule",
    ]
    
    for result in results_sorted:
        line = (
            f"{result['model']:20s} & "
            f"{result['total_samples']:4d} & "
            f"{result['trigger_rate']:5.1%} & "
            f"\\textbf{{{result['attack_success_rate']:5.1%}}} & "
            f"{result['avg_response_length']:5.1f} \\\\"
        )
        lines.append(line)
    
    lines.extend([
        "\\midrule",
        f"Average & - & - & {sum(r['attack_success_rate'] for r in results) / len(results):.1%} & - \\\\",
        "\\bottomrule",
        "\\end{tabular}",
        "\\end{table}",
    ])
    
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="")
    parser.add_argument("--result_dir", type=str, default="results",
                        help="")
    parser.add_argument("--output", type=str, default="results/summary_comparison.md",
                        help="")
    parser.add_argument("--latex", type=str, default="results/summary_table.tex",
                        help="LaTeX")
    
    args = parser.parse_args()
    

    result_dir = Path(args.result_dir)
    if not result_dir.exists():
        print(f": : {result_dir}")
        return
    
    result_files = list(result_dir.glob("*.json"))
    if not result_files:
        print(f": : {result_dir}")
        return
    
    print(f" {len(result_files)} ")
    

    results = []
    for result_file in result_files:
        try:
            result = load_experiment_result(result_file)
            results.append(result)
            print(f"  ✓ {result_file.name}: {result['model']} - {result['attack_success_rate']:.2%}")
        except Exception as e:
            print(f"  ✗ {result_file.name}:  - {e}")
    
    if not results:
        print(": ")
        return
    

    print(f"\nMarkdown: {args.output}")
    markdown_table = generate_summary_table(results)
    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(markdown_table)
    

    print(f"LaTeX: {args.latex}")
    latex_table = generate_latex_table(results)
    with open(args.latex, 'w', encoding='utf-8') as f:
        f.write(latex_table)
    
    print("\n！")
    print(f"- Markdown: {args.output}")
    print(f"- LaTeX: {args.latex}")


if __name__ == "__main__":
    main()
