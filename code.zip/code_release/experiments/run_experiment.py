"""
 - RAG
"""
import os
import sys
import yaml
import json
import argparse
import copy
from tqdm import tqdm
from typing import Dict, List
import torch


sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


from data.sample_queries import load_sampled_queries
from retriever.contriever_retriever import ContrieverRetriever
from retriever.gtr_retriever import GTRRetriever
from trigger.keyword_trigger import KeywordTrigger
from trigger.semantic_trigger import SemanticTrigger, HybridTrigger
from attack.blocker import make_blocker_with_meta
from attack.injector import PromptInjector
from llm.model_loader import load_llm_by_alias, load_llm_for_api
from llm.inference import LLMInference, generate_answer, generate_answer_api
from defense.perplexity_filter import PerplexityFilter
from defense.paraphrase import QueryParaphraser, DocumentParaphraser
from evaluation.metrics import ExperimentMetrics
from evaluation.judge_refusal import RefusalJudge
from utils.context_manager import get_context_manager

class RAGAttackExperiment:
    """RAG"""
    
    def __init__(self, config: Dict):
        """
        
        
        Args:
            config: 
        """
        self.config = config
        self.results = []
        self.metrics = ExperimentMetrics()
        

        self._init_components()
    
    def _init_components(self):
        """"""
        print("...")
        

        print("\n[1/6] ...")
        retriever_config = self.config['retriever']
        if retriever_config['type'] == 'contriever':
            self.retriever = ContrieverRetriever(
                index_path=retriever_config['index_path'],
                mapping_path=retriever_config['mapping_path'],
                doc_path=retriever_config['doc_path'],
                embed_model_name=retriever_config['model_name']
            )
        elif retriever_config['type'] == 'gtr':
            self.retriever = GTRRetriever(
                index_path=retriever_config['index_path'],
                mapping_path=retriever_config['mapping_path'],
                doc_path=retriever_config['doc_path'],
                embed_model_name=retriever_config['model_name']
            )
        else:
            raise ValueError(f": {retriever_config['type']}")
        

        print("\n[2/6] ...")
        trigger_config = self.config['trigger']
        trigger_type = trigger_config['type']
        if trigger_type == 'keyword':
            self.trigger = KeywordTrigger(
                keywords=trigger_config.get('keywords', [])
            )
        elif trigger_type == 'semantic':
            self.trigger = SemanticTrigger(
                trigger_texts=trigger_config.get('trigger_texts', []),
                embed_model_name=trigger_config.get(
                    'embed_model_name',
                    "sentence-transformers/all-MiniLM-L6-v2"
                ),
                similarity_threshold=trigger_config.get('similarity_threshold', 0.7)
            )
        elif trigger_type == 'hybrid':
            keyword_trigger = KeywordTrigger(
                keywords=trigger_config.get('keywords', [])
            )
            semantic_trigger = SemanticTrigger(
                trigger_texts=trigger_config.get('trigger_texts', []),
                embed_model_name=trigger_config.get(
                    'embed_model_name',
                    "sentence-transformers/all-MiniLM-L6-v2"
                ),
                similarity_threshold=trigger_config.get('similarity_threshold', 0.7)
            )
            self.trigger = HybridTrigger(
                keyword_trigger,
                semantic_trigger,
                mode=trigger_config.get('mode', 'or')
            )
        else:
            raise ValueError(f": {trigger_config['type']}")
        

        print("\n[3/6] ...")
        attack_config = self.config['attack']

        llm_config_preview = self.config.get('llm', {})
        model_name = llm_config_preview.get('model_name', '')
        self.injector = PromptInjector(
            prompt_template=attack_config.get('prompt_template', 'basic'),
            model_name=model_name
        )
        if 'qwen' in model_name.lower():
            print(f" Qwen ，: blocker ")
        

        print("\n[4/6] LLM...")
        llm_config = self.config['llm'].copy()
        modelscope_id = llm_config.get('modelscope_id')
        if modelscope_id:
            from llm.model_loader import download_model_from_modelscope
            print(f"ModelScope: {modelscope_id}")
            local_model_path = download_model_from_modelscope(
                modelscope_id,
                llm_config.get('modelscope_revision')
            )
            print(f"ModelScope: {local_model_path}")
            llm_config['model_path'] = local_model_path
        if llm_config['type'] == 'local':
            from llm.model_loader import load_llm_by_alias, load_llm, MODEL_CONFIGS
            

            model_path = llm_config.get('local_path') or llm_config.get('model_path')
            if model_path:
                print(f": {model_path}")
                self.model, self.tokenizer = load_llm(
                    model_path,
                    load_in_8bit=llm_config.get('load_in_8bit', False),
                    load_in_4bit=llm_config.get('load_in_4bit', False),
                    trust_remote_code=llm_config.get('trust_remote_code', False)
                )
            else:

                print(f": {llm_config['model_name']}")
                self.model, self.tokenizer = load_llm_by_alias(
                    llm_config['model_name'],
                    load_in_8bit=llm_config.get('load_in_8bit', False)
                )
            
            self.llm_inference = LLMInference(
                self.model,
                self.tokenizer,
                is_api=False
            )
        elif llm_config['type'] == 'api':
            self.llm_inference = LLMInference(
                None,
                None,
                is_api=True,
                api_name=llm_config['api_name']
            )
        else:
            raise ValueError(f"LLM: {llm_config['type']}")
        

        print("\n[5/6] ...")
        defense_config = self.config['defense']
        
        self.perplexity_filter = None
        if defense_config.get('use_perplexity_filter', False):
            self.perplexity_filter = PerplexityFilter(
                threshold=defense_config.get('perplexity_threshold', 100.0)
            )
        
        self.query_paraphraser = None
        if defense_config.get('use_query_paraphrase', False):
            self.query_paraphraser = QueryParaphraser()
        
        self.doc_paraphraser = None
        if defense_config.get('use_doc_paraphrase', False):
            self.doc_paraphraser = DocumentParaphraser()
        

        print("\n[6/6] ...")
        eval_config = self.config['evaluation']
        self.judge = RefusalJudge(
            method=eval_config.get('judge_method', 'hybrid'),
            use_oracle=eval_config.get('use_oracle', False),
            use_local_judge=eval_config.get('use_local_judge', False),
            local_judge_model=eval_config.get('local_judge_model', 'google/flan-t5-small'),
            local_judge_max_length=eval_config.get('local_judge_max_length', 32),
            strict_texts=[text.lower() for text in eval_config.get('strict_refusal_texts', [])],
            extra_phrases=eval_config.get('extra_refusal_phrases', [])
        )
        

        print("\n[7/7] ...")
        model_name = llm_config.get('model_name', 'default')
        self.context_manager = get_context_manager(
            model_name=model_name,
            tokenizer=self.tokenizer if hasattr(self, 'tokenizer') else None
        )
        
        print("\n!\n")
    
    def run_single_query(self, query: str, query_id: str = "") -> Dict:
        """
        
        
        Args:
            query: 
            query_id: ID
        
        Returns:
            
        """
        result = {
            "query_id": query_id,
            "query": query,
            "triggered": False,
            "attack_success": False,
            "response": "",
            "retrieved_docs": []
        }
        
        try:

            final_query = query
            if self.query_paraphraser:
                final_query = self.query_paraphraser.paraphrase(query)
                result["paraphrased_query"] = final_query
            

            retriever_config = self.config['retriever']
            retrieval_result = self.retriever.retrieve(final_query, top_k=retriever_config['top_k'])

            doc_texts = [doc.text for doc in retrieval_result]
            

            result["original_retrieved_docs"] = doc_texts.copy()
            

            if self.doc_paraphraser:
                doc_texts = self.doc_paraphraser.batch_paraphrase(doc_texts)
                result["paraphrased_docs"] = True
            
            result["retrieved_docs"] = doc_texts
            

            trigger_config = self.config['trigger']
            force_trigger = trigger_config.get('force_trigger', False)
            triggered = force_trigger or self.trigger.check(doc_texts)
            result["triggered"] = triggered
            

            blocker_doc = None
            blocker_meta = {}
            attack_config = self.config['attack']
            if triggered:
                blocker_doc, blocker_meta = make_blocker_with_meta(
                    mode=attack_config['mode'],
                    language=attack_config.get('language', 'en'),
                    topic_hint=query,
                    query=query  
                )
                

                if self.perplexity_filter and self.perplexity_filter.is_suspicious(blocker_doc):
                    print(f"[] ")
                    blocker_doc = None
                    blocker_meta = {}
                
                result["blocker_doc"] = blocker_doc
                result["blocker_meta"] = blocker_meta
                

                if blocker_doc and self.doc_paraphraser:
                    blocker_doc = self.doc_paraphraser.paraphrase(blocker_doc)
                    result["blocker_paraphrased"] = True
            else:
                result["blocker_meta"] = {}
            

            base_repeat = attack_config.get('blocker_repeat', 1)
            meta_repeat = blocker_meta.get('repeat') if triggered else None
            effective_repeat = meta_repeat or base_repeat
            


            if hasattr(self, 'context_manager'):
                doc_texts, was_truncated = self.context_manager.truncate_documents(
                    documents=doc_texts,
                    blocker_text=blocker_doc,
                    blocker_repeat=effective_repeat,
                    insert_position=attack_config.get('insert_position', 'end')
                )
                result["docs_truncated"] = was_truncated
            else:
                result["docs_truncated"] = False
            

            if triggered and blocker_doc:

                injected_docs = self.injector._insert_blocker(
                    doc_texts,
                    blocker_doc,
                    attack_config.get('insert_position', 'end'),
                    effective_repeat
                )

                result["retrieved_docs"] = injected_docs
            

            prompt = self.injector.assemble_prompt(
                final_query,
                doc_texts,
                blocker_doc,
                insert_position=attack_config.get('insert_position', 'end'),
                blocker_repeat=effective_repeat
            )
            
            force_refusal = attack_config.get('force_refusal_output', False)
            skip_generation = attack_config.get('skip_generation_when_forced', False)
            refusal_text = blocker_meta.get(
                'refusal_sentence',
                attack_config.get(
                    'refusal_text',
                    "I apologize, but I cannot assist with that request."
                )
            )
            

            llm_config = self.config['llm']
            llm_type = self.config['llm']['type']
            
            def _run_llm():
                if llm_type == 'local':
                    return generate_answer(
                        self.model,
                        self.tokenizer,
                        prompt,
                        max_new_tokens=llm_config.get('max_new_tokens', 256),
                        temperature=llm_config.get('temperature', 0.7),
                        do_sample=False
                    )
                else:
                    return generate_answer_api(
                        self.config['llm']['api_name'],
                        prompt,
                        model_name=llm_config.get('api_model'),
                        max_tokens=llm_config.get('max_new_tokens', 256)
                    )
            
            if force_refusal and triggered:
                if skip_generation:
                    response = refusal_text
                else:
                    _ = _run_llm()
                    response = refusal_text
            else:
                response = _run_llm()
            
            result["response"] = response
            

            is_refusal = self.judge.is_refusal(query, response)
            result["attack_success"] = is_refusal
            

            self.metrics.add_result(
                attack_success=is_refusal,
                triggered=triggered,
                response=response
            )
            
        except Exception as e:
            print(f": {e}")
            import traceback
            traceback.print_exc()
            result["error"] = str(e)
        
        return result
    
    def run_experiment(self, queries: List[Dict]) -> List[Dict]:
        """
        
        
        Args:
            queries: 
        
        Returns:
            
        """
        print(f"\n， {len(queries)} ...\n")
        
        for i, query_data in enumerate(tqdm(queries, desc="")):
            query = query_data.get('question', query_data.get('query', ''))
            query_id = query_data.get('id', f'query_{i}')
            
            if self.config.get('output', {}).get('verbose', False):
                print(f"\n\n{'='*60}")
                print(f" {i+1}/{len(queries)}: {query}")
                print(f"{'='*60}")
            
            result = self.run_single_query(query, query_id)
            self.results.append(result)
            
            if self.config.get('output', {}).get('verbose', False):
                print(f": {result['triggered']}")
                print(f": {result['attack_success']}")
                print(f": {result['response'][:100]}...")
        
        return self.results
    
    def save_results(self):
        """"""
        output_config = self.config.get('output', {})
        save_dir = output_config.get('save_dir', 'results')
        os.makedirs(save_dir, exist_ok=True)
        

        dataset_name = self.config['dataset']['name']
        retriever_type = self.config['retriever']['type']
        attack_mode = self.config['attack']['mode']
        llm_name = self.config['llm'].get('model_name', self.config['llm'].get('api_model', 'api'))
        
        temperature = self.config.get('llm', {}).get('temperature')
        if isinstance(temperature, (int, float)):
            temp_suffix = f"_temp{temperature:.2f}"
        else:
            temp_suffix = ""

        filename = f"{dataset_name}_{retriever_type}_{attack_mode}_{llm_name}{temp_suffix}.json"
        filepath = os.path.join(save_dir, filename)
        

        output_data = {
            "config": self.config,
            "results": self.results,
            "metrics": self.metrics.compute_all_metrics()
        }
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, indent=2, ensure_ascii=False)
        
        print(f"\n: {filepath}")
        

        summary_file = os.path.join(save_dir, "summary.txt")
        with open(summary_file, 'a', encoding='utf-8') as f:
            f.write(f"\n{'='*60}\n")
            f.write(f": {filename}\n")
            f.write(f"{'='*60}\n")
            for key, value in output_data['metrics'].items():
                f.write(f"{key}: {value}\n")
            f.write("\n")

def load_config(config_path: str) -> Dict:
    """"""
    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    return config

def main():
    """"""
    parser = argparse.ArgumentParser(description="RAG")
    parser.add_argument("--config", type=str, required=True,
                       help="")
    parser.add_argument("--queries", type=str, default=None,
                       help="（）")
    parser.add_argument("--n_queries", type=int, default=None,
                       help="（）")
    parser.add_argument("--temperature_sweep", type=float, nargs='+', default=None,
                       help="")
    parser.add_argument("--sweep_n_queries", type=int, default=500,
                       help="")
    
    args = parser.parse_args()
    

    print(f": {args.config}")
    config = load_config(args.config)
    

    if args.n_queries:
        config['dataset']['n_queries'] = args.n_queries
    

    if args.queries:
        query_file = args.queries
    else:
        dataset_name = config['dataset']['name']
        data_dir = config['dataset']['data_dir']
        query_file = os.path.join(data_dir, dataset_name, "sampled_queries.jsonl")
    
    print(f": {query_file}")
    all_queries = load_sampled_queries(query_file)
    

    global_n = config['dataset'].get('n_queries')
    if global_n and global_n < len(all_queries):
        all_queries = all_queries[:global_n]
    
    print(f" {len(all_queries)} ")

    def run_single_experiment(config_obj: Dict, subset_queries: List[Dict]):
        experiment = RAGAttackExperiment(config_obj)
        experiment.run_experiment(subset_queries)
        experiment.metrics.print_summary()
        experiment.save_results()

    if args.temperature_sweep:
        print(f"\n: {args.temperature_sweep}")
        for temp in args.temperature_sweep:
            sweep_config = copy.deepcopy(config)
            sweep_config['llm']['temperature'] = temp
            sweep_n = min(args.sweep_n_queries, len(all_queries))
            sweep_config['dataset']['n_queries'] = sweep_n
            print(f"\n===  {temp}， {sweep_n} ===")
            queries_subset = all_queries[:sweep_n]
            run_single_experiment(sweep_config, queries_subset)
        print("\n!")
    else:
        queries_to_run = all_queries
        n_queries = config['dataset'].get('n_queries')
        if n_queries and n_queries < len(all_queries):
            queries_to_run = all_queries[:n_queries]
        run_single_experiment(config, queries_to_run)
        print("\n!")

if __name__ == "__main__":
    main()
