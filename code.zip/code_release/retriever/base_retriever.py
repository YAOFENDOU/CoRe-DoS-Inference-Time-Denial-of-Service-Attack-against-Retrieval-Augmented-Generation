"""

"""
from abc import ABC, abstractmethod
from typing import List, Dict, Tuple
import json
import faiss
import numpy as np

class Document:
    """"""
    def __init__(self, doc_id: str, text: str, score: float = 0.0, metadata: Dict = None):
        self.id = doc_id
        self.text = text
        self.score = score
        self.metadata = metadata or {}
    
    def __repr__(self):
        return f"Document(id={self.id}, score={self.score:.4f}, text={self.text[:50]}...)"

class BaseRetriever(ABC):
    """"""
    
    def __init__(self, index_path: str, mapping_path: str, doc_path: str, embed_model_name: str):
        """
        
        
        Args:
            index_path: FAISS
            mapping_path: ID
            doc_path: 
            embed_model_name: 
        """
        self.index_path = index_path
        self.mapping_path = mapping_path
        self.doc_path = doc_path
        self.embed_model_name = embed_model_name
        

        print(f": {index_path}")
        self.index = faiss.read_index(index_path)
        

        print(f": {mapping_path}")
        with open(mapping_path, 'r', encoding='utf-8') as f:
            mapping_data = json.load(f)
            self.doc_ids = mapping_data['doc_ids']
        

        print(f": {doc_path}")
        self.documents_dict = {}
        with open(doc_path, 'r', encoding='utf-8') as f:
            for line in f:
                doc = json.loads(line)
                self.documents_dict[doc['id']] = doc
        
        print(f"，: {self.index.ntotal}")
        

        self.embedder = None
    
    @abstractmethod
    def encode_query(self, query: str) -> np.ndarray:
        """
        
        
        Args:
            query: 
        
        Returns:
            
        """
        pass
    
    def retrieve(self, query: str, top_k: int = 5) -> List[Document]:
        """
        
        
        Args:
            query: 
            top_k: top k
        
        Returns:
            
        """

        query_vec = self.encode_query(query)
        

        if query_vec.ndim == 1:
            query_vec = query_vec.reshape(1, -1)
        

        scores, indices = self.index.search(query_vec, top_k)
        

        documents = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < len(self.doc_ids):
                doc_id = self.doc_ids[idx]
                if doc_id in self.documents_dict:
                    doc_data = self.documents_dict[doc_id]
                    documents.append(Document(
                        doc_id=doc_id,
                        text=doc_data['text'],
                        score=float(score),
                        metadata=doc_data
                    ))
        
        return documents
    
    def batch_retrieve(self, queries: List[str], top_k: int = 5) -> List[List[Document]]:
        """
        
        
        Args:
            queries: 
            top_k: top k
        
        Returns:
            
        """
        results = []
        for query in queries:
            results.append(self.retrieve(query, top_k))
        return results
