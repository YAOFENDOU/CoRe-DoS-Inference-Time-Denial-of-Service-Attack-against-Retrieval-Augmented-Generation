"""
GTR
"""
import numpy as np
import torch
from sentence_transformers import SentenceTransformer
from .base_retriever import BaseRetriever
import faiss

class GTRRetriever(BaseRetriever):
    """GTR"""
    
    def __init__(self, index_path: str, mapping_path: str, doc_path: str,
                 embed_model_name: str = "sentence-transformers/gtr-t5-base"):
        """
        GTR
        
        Args:
            index_path: FAISS
            mapping_path: ID
            doc_path: 
            embed_model_name: GTR
        """
        super().__init__(index_path, mapping_path, doc_path, embed_model_name)
        

        print(f"GTR: {embed_model_name}")
        device = "cuda" if torch.cuda.is_available() else "cpu"
        self.embedder = SentenceTransformer(embed_model_name, device=device)
        print(f"，: {device}")
    
    def encode_query(self, query: str) -> np.ndarray:
        """
        GTR
        
        Args:
            query: 
        
        Returns:
            （，）
        """

        embedding = self.embedder.encode(
            query,
            convert_to_numpy=True,
            show_progress_bar=False,
            normalize_embeddings=True  
        )
        
        return embedding.astype('float32')
    
    def encode_batch(self, texts: list, batch_size: int = 32) -> np.ndarray:
        """
        
        
        Args:
            texts: 
            batch_size: 
        
        Returns:
            （）
        """
        embeddings = self.embedder.encode(
            texts,
            batch_size=batch_size,
            convert_to_numpy=True,
            show_progress_bar=True,
            normalize_embeddings=True
        )
        
        return embeddings.astype('float32')
