"""
Contriever
"""
import numpy as np
import torch
from sentence_transformers import SentenceTransformer
from .base_retriever import BaseRetriever

class ContrieverRetriever(BaseRetriever):
    """Contriever"""
    
    def __init__(self, index_path: str, mapping_path: str, doc_path: str, 
                 embed_model_name: str = "facebook/contriever"):
        """
        Contriever
        
        Args:
            index_path: FAISS
            mapping_path: ID
            doc_path: 
            embed_model_name: Contriever
        """
        super().__init__(index_path, mapping_path, doc_path, embed_model_name)
        

        print(f"Contriever: {embed_model_name}")
        device = "cuda" if torch.cuda.is_available() else "cpu"
        

        import os
        os.environ['SENTENCE_TRANSFORMERS_HOME'] = '/root/.cache/torch/sentence_transformers'
        os.environ['TRANSFORMERS_OFFLINE'] = '1'
        
        try:

            self.embedder = SentenceTransformer(embed_model_name, device=device)
            print(f"，: {device}")
        except Exception as e:
            print(f": {e}")

            local_path = f"/root/.cache/torch/sentence_transformers/{embed_model_name.replace('/', '_')}"
            if os.path.exists(local_path):
                print(f": {local_path}")
                self.embedder = SentenceTransformer(local_path, device=device)
                print(f"（），: {device}")
            else:
                raise RuntimeError(f"Contriever，: {local_path}")
    
    def encode_query(self, query: str) -> np.ndarray:
        """
        Contriever
        
        Args:
            query: 
        
        Returns:
            
        """

        embedding = self.embedder.encode(
            query,
            convert_to_numpy=True,
            show_progress_bar=False
        )
        
        return embedding.astype('float32')
    
    def encode_batch(self, texts: list, batch_size: int = 32) -> np.ndarray:
        """
        
        
        Args:
            texts: 
            batch_size: 
        
        Returns:
            
        """
        embeddings = self.embedder.encode(
            texts,
            batch_size=batch_size,
            convert_to_numpy=True,
            show_progress_bar=True
        )
        
        return embeddings.astype('float32')
