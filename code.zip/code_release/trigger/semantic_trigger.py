"""

"""
from typing import List
import numpy as np
import torch
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

class SemanticTrigger:
    """"""
    
    def __init__(self, trigger_texts: List[str], 
                 embed_model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
                 similarity_threshold: float = 0.7):
        """
        
        
        Args:
            trigger_texts: 
            embed_model_name: 
            similarity_threshold: 
        """
        self.trigger_texts = trigger_texts
        self.similarity_threshold = similarity_threshold
        

        print(f": {embed_model_name}")
        device = "cuda" if torch.cuda.is_available() else "cpu"
        self.embedder = SentenceTransformer(embed_model_name, device=device)
        

        print("...")
        self.trigger_embeddings = self.embedder.encode(
            trigger_texts,
            convert_to_numpy=True,
            show_progress_bar=False
        )
        

        self.trigger_vec = np.mean(self.trigger_embeddings, axis=0)
        
        print(f"，: {similarity_threshold}")
    
    def _compute_similarity(self, text: str) -> float:
        """
        
        
        Args:
            text: 
        
        Returns:
            
        """

        text_embedding = self.embedder.encode(
            text,
            convert_to_numpy=True,
            show_progress_bar=False
        )
        

        similarity = cosine_similarity(
            text_embedding.reshape(1, -1),
            self.trigger_vec.reshape(1, -1)
        )[0][0]
        
        return float(similarity)
    
    def check(self, docs: List[str]) -> bool:
        """
        
        
        Args:
            docs: 
        
        Returns:
            
        """

        for doc in docs:
            similarity = self._compute_similarity(doc)
            if similarity >= self.similarity_threshold:
                return True
        
        return False
    
    def check_single_doc(self, doc: str) -> bool:
        """
        
        
        Args:
            doc: 
        
        Returns:
            
        """
        similarity = self._compute_similarity(doc)
        return similarity >= self.similarity_threshold
    
    def get_similarities(self, docs: List[str]) -> List[float]:
        """
        
        
        Args:
            docs: 
        
        Returns:
            
        """
        similarities = []
        for doc in docs:
            sim = self._compute_similarity(doc)
            similarities.append(sim)
        
        return similarities
    
    def check_with_details(self, docs: List[str]) -> dict:
        """
        
        
        Args:
            docs: 
        
        Returns:
            
        """
        similarities = self.get_similarities(docs)
        triggered = any(sim >= self.similarity_threshold for sim in similarities)
        
        return {
            "triggered": triggered,
            "similarities": similarities,
            "max_similarity": max(similarities) if similarities else 0.0,
            "threshold": self.similarity_threshold
        }

class HybridTrigger:
    """（）"""
    
    def __init__(self, keyword_trigger, semantic_trigger, mode: str = "or"):
        """
        
        
        Args:
            keyword_trigger: 
            semantic_trigger: 
            mode:  ("or"  "and")
        """
        self.keyword_trigger = keyword_trigger
        self.semantic_trigger = semantic_trigger
        self.mode = mode
        
        print(f"，: {mode}")
    
    def check(self, docs: List[str]) -> bool:
        """
        
        
        Args:
            docs: 
        
        Returns:
            
        """
        keyword_triggered = self.keyword_trigger.check(docs)
        semantic_triggered = self.semantic_trigger.check(docs)
        
        if self.mode == "or":
            return keyword_triggered or semantic_triggered
        elif self.mode == "and":
            return keyword_triggered and semantic_triggered
        else:
            raise ValueError(f": {self.mode}")
