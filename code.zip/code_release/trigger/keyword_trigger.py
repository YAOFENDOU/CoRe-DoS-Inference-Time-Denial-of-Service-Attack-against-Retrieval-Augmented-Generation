"""

"""
from typing import List
import re

class KeywordTrigger:
    """"""
    
    def __init__(self, keywords: List[str], case_sensitive: bool = False):
        """
        
        
        Args:
            keywords: 
            case_sensitive: 
        """
        self.keywords = keywords
        self.case_sensitive = case_sensitive
        
        if not case_sensitive:
            self.keywords = [kw.lower() for kw in keywords]
        
        print(f"，: {len(self.keywords)}")
    
    def check(self, docs: List[str]) -> bool:
        """
        
        
        Args:
            docs: 
        
        Returns:
            
        """

        combined_text = " ".join(docs)
        
        if not self.case_sensitive:
            combined_text = combined_text.lower()
        

        for keyword in self.keywords:
            if keyword in combined_text:
                return True
        
        return False
    
    def check_single_doc(self, doc: str) -> bool:
        """
        
        
        Args:
            doc: 
        
        Returns:
            
        """
        if not self.case_sensitive:
            doc = doc.lower()
        
        for keyword in self.keywords:
            if keyword in doc:
                return True
        
        return False
    
    def get_matched_keywords(self, docs: List[str]) -> List[str]:
        """
        
        
        Args:
            docs: 
        
        Returns:
            
        """
        combined_text = " ".join(docs)
        
        if not self.case_sensitive:
            combined_text = combined_text.lower()
        
        matched = []
        for keyword in self.keywords:
            if keyword in combined_text:
                matched.append(keyword)
        
        return matched

class RegexTrigger:
    """"""
    
    def __init__(self, patterns: List[str], flags: int = re.IGNORECASE):
        """
        
        
        Args:
            patterns: 
            flags: 
        """
        self.patterns = [re.compile(p, flags) for p in patterns]
        print(f"，: {len(self.patterns)}")
    
    def check(self, docs: List[str]) -> bool:
        """
        
        
        Args:
            docs: 
        
        Returns:
            
        """
        combined_text = " ".join(docs)
        
        for pattern in self.patterns:
            if pattern.search(combined_text):
                return True
        
        return False
    
    def check_single_doc(self, doc: str) -> bool:
        """
        
        
        Args:
            doc: 
        
        Returns:
            
        """
        for pattern in self.patterns:
            if pattern.search(doc):
                return True
        
        return False
